#include "global.hpp"
#pragma once

extern void checkIfVariableExists(int id);